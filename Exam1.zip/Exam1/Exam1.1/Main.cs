﻿using Exam1._1;
using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Numerics;
using System.Text;

class MainClass
{
    // Method to handle the main menu for working with the dictionary
    public static void menu_for_workWith_Function(ref Dictonary_class obj)
    {
        // Display the menu options
        Console.WriteLine("\n\n1.Add word" + '\n' + "2.Change word or change translate" + '\n' +
                          "3.Delete word or delete translate word" + '\n' + "4.Seach translate" + '\n' + "0.Back to main menu" + '\n');

        string? input_menu = Console.ReadLine();
        int menu = 0;

        if (int.TryParse(input_menu, out menu))
        {
            Function func = new Function(obj.get_filePath());

            switch (menu)
            {
                case 1:
                    // Adding a word and its translation to the dictionary
                    Console.Write("Enter word which you want add: ");
                    string add_word = Console.ReadLine();

                    Console.Write("Enter translate: ");
                    string translate_word = Console.ReadLine();

                    func.AddWord(add_word, translate_word);
                    menu_for_workWith_Function(ref obj);
                    break;
                case 2:
                    // Update word or translation based on user choice
                    Console.WriteLine("What you want change?" + '\n' + "1.Word\t2.Translate" + '\n');
                    string temp_menu = Console.ReadLine();
                    int menu_temp = 0;
                    if (int.TryParse(temp_menu, out menu_temp))
                    {
                        if (menu_temp == 1)
                        {
                            // Update word
                            Console.Write("Enter word which you want change: ");
                            string old_word = Console.ReadLine();

                            Console.Write("Enter translate: ");
                            string new_translate = Console.ReadLine();

                            func.UpdateWord(old_word, new_translate);
                        }
                        else if (menu_temp == 2)
                        {
                            // Update translation
                            Console.Write("Enter word which you want change: ");
                            string old_word = Console.ReadLine();

                            Console.Write("Enter old translate: ");
                            string old_translate = Console.ReadLine();

                            Console.Write("Enter new translate: ");
                            string new_translate = Console.ReadLine();

                            func.UpdateTranslation(old_word, old_translate, new_translate);
                        }
                        else
                        {
                            Console.WriteLine("Error with your choice!");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Error with your menu!" + '\n' + "Please enter again!" + '\n');
                    }
                    menu_for_workWith_Function(ref obj);
                    break;
                case 3:
                    // Delete word or translation based on user choice
                    Console.Write("Enter word which you want remove: ");
                    string remove_word = Console.ReadLine();
                    func.Remove_Word(remove_word);
                    menu_for_workWith_Function(ref obj);
                    break;
                case 4:
                    // Search for a translation based on a word
                    Console.Write("Enter the word to search: ");
                    string wordToSearch_e = Console.ReadLine();
                    func.Search_Word(wordToSearch_e);
                    menu_for_workWith_Function(ref obj);
                    break;
                case 5:
                    Console.Write("Enter word for export translate:");
                    string? word = Console.ReadLine();
                    Console.Write("Enter filePath for export:");
                    string? filePath = Console.ReadLine();
                    func.ExportWordAndTranslations(word, filePath);
                    menu_for_workWith_Function(ref obj);
                    break;
                case 0:
                    // Go back to the main menu
                    Main();
                    break;
                default:
                    Console.WriteLine("Error with your choice!\n" + "Please enter again!!!");
                    menu_for_workWith_Function(ref obj);
                    break;
            }
        }
        else
        {
            Console.WriteLine("Error!\tNeed be number!!!");
            menu_for_workWith_Function(ref obj);
        }
    }

    // Method to set 50 words with English translations
    public static void set50WordsEnglish(Dictionary<string, string> dic)
    {

        dic.Add("Город", "City"); dic.Add("Кулка", "Doll");
        dic.Add("Пончик", "Donut"); dic.Add("Планета", "Earth");
        dic.Add("Око", "Eye"); dic.Add("Рыба", "Fish");
        dic.Add("Ферма", "Farm"); dic.Add("Глобус", "Globe");
        dic.Add("Дом", "House"); dic.Add("Интернет", "Internet");

        dic.Add("Сок", "Juice"); dic.Add("Ключ", "Key");
        dic.Add("Собака", "Dog"); dic.Add("Лимон", "Lemon");
        dic.Add("Карта", "Map"); dic.Add("Ноутбук", "Laptop");
        dic.Add("Замок", "Castle"); dic.Add("Хлеб", "Bread");
        dic.Add("Мотоцикл", "Motorcycle"); dic.Add("Смартфон", "Smartphone");

        dic.Add("Небо", "Sky"); dic.Add("Остров", "Island");
        dic.Add("Вода", "Water"); dic.Add("Солнце", "Sun");
        dic.Add("Телефон", "Phone"); dic.Add("Муравейник", "Ant hill");
        dic.Add("Отец", "Father"); dic.Add("Мама", "Mother");
        dic.Add("Робот", "Robot"); dic.Add("Парк", "Park");

        dic.Add("Кино", "Movie"); dic.Add("Слухи", "Gossip");
        dic.Add("Смех", "Laughter"); dic.Add("Шляпа", "Hat");
        dic.Add("Рука", "Hand"); dic.Add("Цветок", "Flower");
        dic.Add("Музыка", "Music"); dic.Add("Молоко", "Milk");
        dic.Add("Час", "Hour"); dic.Add("Лето", "Summer");

        dic.Add("Пицца", "Pizza"); dic.Add("Ветер", "Wind");
        dic.Add("Театр", "Theater"); dic.Add("Вино", "Wine");
        dic.Add("Село", "Town"); dic.Add("Самолет", "Airplane");
        dic.Add("Учитель", "Teacher"); dic.Add("Месяць", "Moon");
        dic.Add("Звезда", "Star"); dic.Add("Книга", "Book");
    }

    // Method to set 50 words with swapped key-value pairs
    public static void set50WordsChangeKeyValue(Dictionary<string, string> dic)
    {
        Dictionary<string, string> tempDictionary = new Dictionary<string, string>();

        // Додавання слів до тимчасового словника з поміняними ключами і значеннями
        foreach (var entry in dic)
        {
            tempDictionary.Add(entry.Value, entry.Key);
        }

        // Копіювання тимчасового словника до основного словника
        dic.Clear();
        foreach (var entry in tempDictionary)
        {
            dic.Add(entry.Key, entry.Value);
        }
    }
    public static void Main()
    {
        int user_menu = 0;

        // Display the main menu options
        Console.WriteLine("1.Dictionary Russia-English" + '\n' + "2.Dictionary English-Russia" + '\n' + "3.Connect an existing dictionary" + '\n' + "0.Close program");
        Console.Write("Please enter: ");

        string? input_user_menu = Console.ReadLine();

        if (int.TryParse(input_user_menu, out user_menu))
        {
            //My const filePaths:

            //For Russia-English
            string? filePath_r = "C:\\Users\\coolm\\source\\repos\\Exam1\\Exam1.1\\Russia_English.txt";

            //For English-Russia
            string? filePath_e = "C:\\Users\\coolm\\source\\repos\\Exam1\\Exam1.1\\English_Russia.txt";

            switch (user_menu)
            {
                case 0:
                    // Exit the program if 0 is selected
                    break;
                case 1:
                    // Create a new instance of the Dictonary_class for Russia-English dictionary
                    Dictonary_class russia_en = new Dictonary_class(filePath_r);

                    Dictionary<string, string> dic = new Dictionary<string, string>();

                    // Set 50 words with English translations
                    set50WordsEnglish(dic);
                    russia_en.set_dictionary(ref dic);

                    // Create a file and read its content
                    russia_en.CreateFile_txt(filePath_r);
                    russia_en.ReadFile_txt(filePath_r);

                    // Go to the menu for working with the dictionary
                    menu_for_workWith_Function(ref russia_en);
                    break;
                case 2:
                    // Create a new instance of the Dictonary_class for English-Russia dictionary
                    Dictonary_class english_rus = new Dictonary_class(filePath_e);

                    Dictionary<string, string> dic_e = new Dictionary<string, string>();

                    // Set 50 words with English translations and swap key-value pairs
                    set50WordsEnglish(dic_e);
                    set50WordsChangeKeyValue(dic_e);
                    english_rus.set_dictionary(ref dic_e);

                    // Create a file and read its content
                    english_rus.CreateFile_txt(filePath_e);
                    english_rus.ReadFile_txt(filePath_e);

                    // Go to the menu for working with the dictionary
                    menu_for_workWith_Function(ref english_rus);
                    break;
                case 3:
                    // Connect an existing dictionary by providing its file path
                    Console.WriteLine("Please enter your filePath dictionary!");

                    string? myfilePath = Console.ReadLine();

                    Dictonary_class myDic_class = new Dictonary_class(myfilePath);

                    Dictionary<string, string> myDic = new Dictionary<string, string>();

                    // Set the dictionary from the existing file and read its content
                    myDic_class.set_dictionary(ref myDic);
                    myDic_class.ReadFile_txt(myfilePath);

                    // Go to the menu for working with the dictionary
                    menu_for_workWith_Function(ref myDic_class);
                    break;
                default:
                    Console.WriteLine("Error with your choice\n" + "Please enter again!!!");
                    Main();
                    break;
            }
        }
        else
        {
            Console.WriteLine("Error!\tNeed be number!!!");
            Main();
        }
    }
}