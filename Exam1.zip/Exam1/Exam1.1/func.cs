﻿using System;
using Exam1._1;

namespace Exam1._1
{
    internal class Function : Dictonary_class
    {
        public Function(string filePath) : base(filePath) { }

        public void Remove_Word(string wordToRemove)
        {
            // Read data from the file and update the dictionary
            ReadFile_txt(filePath);

            if (_dictionary.ContainsKey(wordToRemove))
            {
                _dictionary.Remove(wordToRemove);

                // Rewrite the dictionary to the file without the wordToRemove
                using (StreamWriter sw = new StreamWriter(filePath, false))
                {
                    foreach (var entry in _dictionary)
                    {
                        string key = entry.Key;
                        List<string> values = entry.Value;
                        string translationsString = string.Join(", ", values); // Join translations into a single string
                        sw.WriteLine($"{key} - {translationsString}");
                    }
                }

                Console.WriteLine($"\nWord '{wordToRemove}' removed.");
            }
            else
            {
                Console.WriteLine($"Element with key '{wordToRemove}' not found.");
            }
        }

        public void AddWord(string add_word, string translate_word)
        {
            // Read data from the file and update the dictionary
            ReadFile_txt(filePath);

            if (!_dictionary.ContainsKey(add_word))
            {
                // Create a new list for storing translations and add the first translation to it
                List<string> translations = new List<string> { translate_word };
                _dictionary.Add(add_word, translations);
                Console.WriteLine($"Word '{add_word}' added: {translate_word}");
            }
            else
            {
                // If the word already exists in the dictionary, add the new translation to the list
                List<string> translations = _dictionary[add_word];
                if (!translations.Contains(translate_word))
                {
                    translations.Add(translate_word);
                    Console.WriteLine($"Translation '{translate_word}' added to '{add_word}'.");
                }
                else
                {
                    Console.WriteLine($"Translation '{translate_word}' already exists for '{add_word}'.");
                }
            }

            // Rewrite the dictionary to the file
            try
            {
                using (StreamWriter sw = new StreamWriter(filePath, false))
                {
                    foreach (var entry in _dictionary)
                    {
                        string key = entry.Key;
                        List<string> values = entry.Value;
                        string translationsString = string.Join(", ", values); // Join translations into a single string
                        sw.WriteLine($"{key} - {translationsString}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error writing to the file: {ex.Message}");
            }
        }

        public void UpdateWord(string update_word, string new_translation)
        {
            // Read data from the file and update the dictionary
            ReadFile_txt(filePath);

            if (_dictionary.ContainsKey(update_word))
            {
                _dictionary[update_word] = new List<string> { new_translation };

                // Rewrite the dictionary to the file with the updated translation
                using (StreamWriter sw = new StreamWriter(filePath, false))
                {
                    foreach (var entry in _dictionary)
                    {
                        string key = entry.Key;
                        List<string> values = entry.Value;
                        string translationsString = string.Join(", ", values); // Join translations into a single string
                        sw.WriteLine($"{key} - {translationsString}");
                    }
                }

                Console.WriteLine($"Word '{update_word}' updated: {new_translation}");
            }
            else
            {
                Console.WriteLine($"Element with key '{update_word}' not found. Use 'AddWord' to add a new element.");
            }
        }

        public void ExportWordAndTranslations(string word, string filePath)
        {
            var translations = GetTranslations(word); // This is a method that returns all translations for a given word

            using (var streamWriter = new StreamWriter(filePath, true))
            {
                streamWriter.WriteLine($"Word: {word}");

                foreach (var translation in translations)
                {
                    streamWriter.WriteLine($"Translation: {translation}");
                }
            }
        }

        public void UpdateTranslation(string update_word, string old_translation, string new_translation)
        {
            // Read data from the file and update the dictionary
            ReadFile_txt(filePath);

            if (_dictionary.ContainsKey(update_word))
            {
                List<string> translations = _dictionary[update_word];
                if (translations.Contains(old_translation))
                {
                    translations.Remove(old_translation); // Remove the old translation
                    translations.Add(new_translation); // Add the new translation

                    // Rewrite the dictionary to the file with the updated translations
                    using (StreamWriter sw = new StreamWriter(filePath, false))
                    {
                        foreach (var entry in _dictionary)
                        {
                            string key = entry.Key;
                            List<string> values = entry.Value;
                            string translationsString = string.Join(", ", values); // Join translations into a single string
                            sw.WriteLine($"{key} - {translationsString}");
                        }
                    }

                    Console.WriteLine($"Translation for '{update_word}' updated: {old_translation} -> {new_translation}");
                }
                else
                {
                    Console.WriteLine($"Translation '{old_translation}' not found for '{update_word}'.");
                }
            }
            else
            {
                Console.WriteLine($"Element with key '{update_word}' not found. Use 'AddWord' to add a new element.");
            }
        }

        public void Search_Word(string keyToSearch)
        {
            try
            {
                using (StreamReader sr = new StreamReader(filePath))
                {
                    bool found = false;
                    while (!sr.EndOfStream)
                    {
                        string line = sr.ReadLine();
                        string[] parts = line.Split(new char[] { '-' }, 2, StringSplitOptions.RemoveEmptyEntries);
                        if (parts.Length == 2)
                        {
                            string word = parts[0].Trim();
                            string translation = parts[1].Trim();

                            if (word == keyToSearch)
                            {
                                Console.WriteLine($"Value for key '{keyToSearch}' found in the file: {translation}");
                                found = true;
                            }
                        }
                    }

                    if (!found)
                    {
                        // Key not found in the file or dictionary
                        if (_dictionary.ContainsKey(keyToSearch))
                        {
                            // Found in the dictionary
                            List<string> translations = _dictionary[keyToSearch];
                            string translationsString = string.Join(", ", translations);
                            Console.WriteLine($"Value for key '{keyToSearch}' in the dictionary: {translationsString}");
                        }
                        else
                        {
                            // Key not found in the dictionary either
                            Console.WriteLine($"Element with key '{keyToSearch}' not found in the file or dictionary.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading the file: {ex.Message}");
            }
        }
    }
}
