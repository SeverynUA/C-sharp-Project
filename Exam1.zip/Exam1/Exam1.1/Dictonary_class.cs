﻿using System;
using Exam1._1;


namespace Exam1._1
{
    internal class Dictonary_class
    {
        protected Dictionary<string, List<string>> _dictionary = new Dictionary<string, List<string>>();
        protected string filePath;

        public Dictonary_class(string filePath)
        {
            this.filePath = filePath;
        }

        public List<string> GetTranslations(string word)
        {
            if (_dictionary.ContainsKey(word))
            {
                return _dictionary[word];
            }
            else
            {
                return null;
            }
        }

        public void ReadFile_txt(string filePath)
        {
            try
            {
                _dictionary.Clear(); // Clear the dictionary before reading the file

                using (StreamReader sr = new StreamReader(filePath))
                {
                    while (!sr.EndOfStream)
                    {
                        string line = sr.ReadLine();
                        string[] parts = line.Split(new char[] { '-' }, 2, StringSplitOptions.RemoveEmptyEntries);
                        if (parts.Length == 2)
                        {
                            string word = parts[0].Trim();
                            string translation = parts[1].Trim();

                            if (_dictionary.ContainsKey(word))
                            {
                                // Add a new translation to an existing word in the dictionary
                                List<string> translations = _dictionary[word];
                                if (!translations.Contains(translation))
                                {
                                    translations.Add(translation);
                                }
                            }
                            else
                            {
                                // Add a new word with its translation to the dictionary
                                List<string> translations = new List<string> { translation };
                                _dictionary.Add(word, translations);
                            }
                        }
                    }
                }

                // Display the dictionary contents after reading
                Console.WriteLine("Dictionary contents:");
                foreach (var entry in _dictionary)
                {
                    string key = entry.Key;
                    List<string> values = entry.Value;
                    string translationsString = string.Join(", ", values);
                    Console.WriteLine($"{key} - {translationsString}");
                }
            }
            catch (Exception ex)
            {
                // Handle errors (display or log the error)
                Console.WriteLine($"Error reading the file: {ex.Message}");
            }
        }

        public void CreateFile_txt(string filePath)
        {
            using (StreamWriter sw = new StreamWriter(filePath, false))
            {
                foreach (var entry in _dictionary)
                {
                    string key = entry.Key;
                    List<string> values = entry.Value;
                    string translationsString = string.Join(", ", values); // Join translations into a single string
                    sw.WriteLine($"{key} - {translationsString}");
                }
            }
        }

        public override string ToString()
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            foreach (var entry in _dictionary)
            {
                string key = entry.Key;
                List<string> values = entry.Value;
                string translationsString = string.Join(", ", values); // Join translations into a single string
                sb.AppendLine($"{key} - {translationsString}");
            }

            return sb.ToString();
        }

        public string get_filePath() { return filePath; }

        public void set_dictionary(ref Dictionary<string, string> new_dic)
        {
            _dictionary = new Dictionary<string, List<string>>();

            foreach (var entry in new_dic)
            {
                string key = entry.Key;
                string translation = entry.Value;

                if (_dictionary.ContainsKey(key))
                {
                    List<string> translations = _dictionary[key];
                    translations.Add(translation);
                }
                else
                {
                    List<string> translations = new List<string> { translation };
                    _dictionary[key] = translations;
                }
            }
        }
    }
}