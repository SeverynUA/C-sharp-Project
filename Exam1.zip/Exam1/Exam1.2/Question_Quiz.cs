﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam1._2
{
    public struct Question
    {
        public string QuestionText;
        public List<string> AnswerOptions;
        public List<int> CorrectAnswerIndices;
    }

    public class Question_Quiz
    {
        public Dictionary<string, List<int>> correctAnswersHistory;
        public Dictionary<string, List<int>> correctAnswersGeography;
        public Dictionary<string, List<int>> correctAnswersScience;
        public Dictionary<string, List<int>> correctAnswersMovies;
        public Dictionary<string, List<int>> correctAnswersLiterature;
        public Dictionary<string, List<int>> correctAnswersMixTopic;

        public Question_Quiz()
        {
            correctAnswersHistory = new Dictionary<string, List<int>>();
            correctAnswersGeography = new Dictionary<string, List<int>>();
            correctAnswersScience = new Dictionary<string, List<int>>();
            correctAnswersMovies = new Dictionary<string, List<int>>();
            correctAnswersLiterature = new Dictionary<string, List<int>>();
            correctAnswersMixTopic = new Dictionary<string, List<int>>();
        }

        public static void AddQuestionWithAnswers(Question question, ref Dictionary<string, List<string>> topic_ask, ref Dictionary<string, List<int>> correctAnswers)
        {
            string[] answerOptions = question.AnswerOptions.ToArray();

            Random random = new Random();
            int n = answerOptions.Length;
            while (n > 1)
            {
                n--;
                int k = random.Next(n + 1);
                string value = answerOptions[k];
                answerOptions[k] = answerOptions[n];
                answerOptions[n] = value;
            }

            string questionText = question.QuestionText;

            if (!topic_ask.ContainsKey(questionText) && !correctAnswers.ContainsKey(questionText))
            {
                topic_ask.Add(questionText, new List<string>(answerOptions));
                correctAnswers.Add(questionText, question.CorrectAnswerIndices);
            }
            else if (correctAnswers.ContainsKey(questionText)) // Update correct answers for the question
            {
                correctAnswers[questionText] = question.CorrectAnswerIndices;
            }
        }

        public void Question_History(Dictionary<string, List<string>> history)
        {
            history.Add("Who were the main participants in the Cold War during the second half of the 20th century?",
                new List<string> {"United States of America and Soviet Union","Soviet Union and United Kingdom","United States of America and Germany","China and United States of America"});

            history.Add("In which year did the First World War start?",
                new List<string> { "1910", "1914", "1918", "1922" });

            history.Add("Who discovered America?",
                new List<string> { "Christopher Columbus", "Vasco da Gama", "Marco Polo", "Ferdinand Magellan" });

            history.Add("Who was the president of United States during the Civil War?",
                new List<string> { "George Washington", "Thomas Jefferson", "Abraham Lincoln", "Franklin Roosevelt" });

            history.Add("What was the name of the ship on which the Pilgrims travelled to America in 1620?",
                new List<string> { "Titanic", "Santa Maria", "Mayflower", "HMS Beagle" });

            history.Add("What is the name of the last Tsar of Russia?",
                new List<string> { "Peter the Great", "Ivan the Terrible", "Nicholas II", "Alexander III" });

            history.Add("Which city was the first capital of ancient Egypt?",
                new List<string> { "Memphis", "Thebes", "Cairo", "Luxor" });

            history.Add("What is the oldest known civilization?",
                new List<string> { "Sumerian", "Egyptian", "Indus Valley", "Chinese" });

            history.Add("Who was the first emperor of Rome?",
                new List<string> { "Julius Caesar", "Augustus", "Nero", "Marcus Aurelius" });

            history.Add("Who wrote the 'Iliad' and the 'Odyssey'?",
                new List<string> { "Socrates", "Homer", "Plato", "Aristotle" });

            //Next multipy variants
            
            history.Add("Which of the following inventions were made in ancient China?",
                new List<string> { "Firearms", "Compass", "Printing press", "Telephone" });

            history.Add("Which of the following cities served as capitals of the Roman Empire at different periods?",
                new List<string> { "Rome", "Constantinople", " Athens", " Mediolanum" });

            history.Add("Which of the following territories were colonies of Great Britain ? ",
                new List<string> { "Canada", "Australia", "France", "India" });

            history.Add("Which of the following events occurred during World War I?",
                new List<string> { "Signing of the Third General Army Order", "Battle of the Somme", "Launch of the \"Titanic\"", "Armenian genocide" });

            history.Add("Who were the rulers of France during the French Revolution?",
                new List<string> { "Louis XVI", "Napoleon Bonaparte", "Marie Antoinette", "Robespierre" });

            history.Add("Which of the following events took place during World War II?",
                new List<string> { "Battle of Stalingrad", "Fall of the Berlin Wall", "Dropping of the atomic bomb on Hiroshima", "D-Day (Normandy landings)" });

            history.Add("Which of the following documents were created during the American Revolution?",
                new List<string> { "Declaration of Independence of the USA", "Constitution of the USA", "Communist Manifesto", "Bill of Rights" });

            history.Add("Which of the following countries were allies of the USA during the Cold War?",
                new List<string> { "Canada", "United Kingdom", "France", "Soviet Union" });

            history.Add("Which of the following events happened in the 20th century?",
                new List<string> { " Establishment of the UN", "World War I", "World War II", " Fall of the Roman Empire" });

            history.Add("Which of the following historical figures was a king of England?",
                new List<string> { "Henry VIII", "Charles I", "Elizabeth II", "Napoleon Bonaparte" });
        }

        public void AddCorrectAnswers_History(Dictionary<string, List<int>> correctAnswersHistory)
        {
            correctAnswersHistory.Add("Who were the main participants in the Cold War during the second half of the 20th century?", new List<int> { 0 });
            correctAnswersHistory.Add("In which year did the First World War start?", new List<int> { 0 }); 
            correctAnswersHistory.Add("Who discovered America?", new List<int> { 0 });
            correctAnswersHistory.Add("Who was the president of United States during the Civil War?", new List<int> { 0 });
            correctAnswersHistory.Add("What was the name of the ship on which the Pilgrims travelled to America in 1620?", new List<int> { 1 });
            correctAnswersHistory.Add("What is the name of the last Tsar of Russia?", new List<int> { 1 });
            correctAnswersHistory.Add("Which city was the first capital of ancient Egypt?", new List<int> { 0 });
            correctAnswersHistory.Add("What is the oldest known civilization?", new List<int> { 0});
            correctAnswersHistory.Add("Who was the first emperor of Rome?", new List<int> { 1 });
            correctAnswersHistory.Add("Who wrote the 'Iliad' and the 'Odyssey'?", new List<int> { 1 });
            //
            correctAnswersHistory.Add("Which of the following inventions were made in ancient China?", new List<int> { 0,1,2 });
            correctAnswersHistory.Add("Which of the following cities served as capitals of the Roman Empire at different periods?", new List<int> { 0,1,3 });
            correctAnswersHistory.Add("Which of the following territories were colonies of Great Britain?", new List<int> { 0,1,3 });
            correctAnswersHistory.Add("Which of the following events occurred during World War I?", new List<int> { 1,3});
            correctAnswersHistory.Add("Who were the rulers of France during the French Revolution?", new List<int> { 0,3 });
            correctAnswersHistory.Add("Which of the following events took place during World War II?", new List<int> { 0,1,3 });
            correctAnswersHistory.Add("Which of the following documents were created during the American Revolution?", new List<int> { 0,1,3 });
            correctAnswersHistory.Add("Which of the following countries were allies of the USA during the Cold War?", new List<int> { 0,1,2 });
            correctAnswersHistory.Add("Which of the following events happened in the 20th century?", new List<int> { 0,1,2 });
            correctAnswersHistory.Add("Which of the following historical figures was a king of England?", new List<int> { 0, 1, 2 });
        }

        public void Question_Geography(Dictionary<string, List<string>> geography)
        {
            geography.Add("What is the largest country in the world?",
                new List<string> { "Russia", "Canada", "USA", "China" });

            geography.Add("Where is the Sahara, the largest desert in the world, located?",
                new List<string> { "North Africa", "South Africa", "South America", "Middle East" });

            geography.Add("Which country is considered the homeland of beavers?",
                new List<string> { "Canada", "Poland", "Italy", "Brazil" });

            geography.Add("The largest lake in the world by area is:",
                new List<string> { "Caspian Sea", "Upper Lake", "Great Bear Lake", "Lake Superior" });

            geography.Add("Where are the largest rainforests in the world - the Amazon rainforest - located?",
                new List<string> { "South America", "Africa", "Australia", "Europe" });

            geography.Add("In which ocean is the largest island - Greenland - located?",
                new List<string> { "Arctic Ocean", "Pacific Ocean", "Atlantic Ocean", "Indian Ocean" });

            geography.Add("What is the highest mountain in the world?",
                new List<string> { "Mount Everest", "Kilimanjaro", "McKinley", "Aconcagua" });

            geography.Add("Where is the tallest waterfall in the world - Angel Falls - located?",
                new List<string> { "Venezuela", "Canada", "Brazil", "America" });

            geography.Add("Which country has the largest population?",
                new List<string> { "China", "India", "USA", "Indonesia" });

            geography.Add("Where is the Holy Grail, the legendary cup from which Jesus Christ drank during the Last Supper, located?",
                new List<string> { "Naples, Italy", "Louvre, Paris", "Cairo, Egypt", "Valencia, Spain" });
            //
            geography.Add("Which of the following cities are located on the banks of the Dnieper River?",
                new List<string> { "Kyiv", "Lviv", "Dnipro", "Chernihiv" });

            geography.Add("In which countries are the Alps located?",
                new List<string> { "Italy", "Germany", "France", "Austria" });

            geography.Add("Which of the following lakes are the largest by area in the world?",
                new List<string> { "Victoria", "Caspian", "Baikal", "Superior" });

            geography.Add("Which of the following countries are members of the European Union?",
                new List<string> { "Sweden", "Norway", "Poland", "Spain" });

            geography.Add("In which countries are the Andes located?",
                new List<string> { "Argentina", "Brazil", "Chile", "Peru" });

            geography.Add("In which countries does the Amazon River flow?",
                new List<string> { "Brazil", "Argentina", "Colombia", "Peru" });

            geography.Add("Which of the following cities are capitals of their countries?",
                new List<string> { "Sydney", "Berlin", "Beijing", "Ottawa" });

            geography.Add("Which of the following countries are islands?",
                new List<string> { "Australia", "Canada", "Japan", "Great Britain" });

            geography.Add("In which countries is the Sahara located?",
                new List<string> { "Egypt", "Morocco", "Libya", "India" });

            geography.Add("Which of the following cities are located on the Black Sea coast?",
                new List<string> { "Odessa", "Istanbul", "Sofia", "Sevastopol" });
        }

        public void AddCorrectAnswers_Geography(Dictionary<string, List<int>> correctAnswersGeography)
        {
            correctAnswersGeography.Add("What is the largest country in the world?", new List<int> { 0 });
            correctAnswersGeography.Add("Where is the Sahara, the largest desert in the world, located?", new List<int> { 0 });
            correctAnswersGeography.Add("Which country is considered the homeland of beavers?", new List<int> { 0 });
            correctAnswersGeography.Add("The largest lake in the world by area is:", new List<int> { 0 });
            correctAnswersGeography.Add("Where are the largest rainforests in the world - the Amazon rainforest - located?", new List<int> { 0 });
            correctAnswersGeography.Add("In which ocean is the largest island - Greenland - located?", new List<int> { 0 });
            correctAnswersGeography.Add("What is the highest mountain in the world?", new List<int> { 0 });
            correctAnswersGeography.Add("Where is the tallest waterfall in the world - Angel Falls - located?", new List<int> { 0 });
            correctAnswersGeography.Add("Which country has the largest population?", new List<int> { 0 });
            correctAnswersGeography.Add("Where is the Holy Grail, the legendary cup from which Jesus Christ drank during the Last Supper, located?", new List<int> { 0 });
            //
            correctAnswersGeography.Add("Which of the following cities are located on the banks of the Dnieper River?", new List<int> { 0,1,3 });
            correctAnswersGeography.Add("In which countries are the Alps located?", new List<int> { 0, 1, 3 });
            correctAnswersGeography.Add("Which of the following lakes are the largest by area in the world?", new List<int> { 0, 1, 3 });
            correctAnswersGeography.Add("Which of the following countries are members of the European Union?", new List<int> { 0,2,3 });
            correctAnswersGeography.Add("In which countries are the Andes located?", new List<int> { 0, 2, 3 });
            correctAnswersGeography.Add("In which countries does the Amazon River flow?", new List<int> { 0,2,3 });
            correctAnswersGeography.Add("Which of the following cities are capitals of their countries?", new List<int> { 1, 2, 3 });
            correctAnswersGeography.Add("Which of the following countries are islands?",new List<int> { 0, 2, 3 });
            correctAnswersGeography.Add("In which countries is the Sahara located?", new List<int> { 0, 1, 2 });
            correctAnswersGeography.Add("Which of the following cities are located on the Black Sea coast?",new List<int> { 0, 1, 2 });
        }

        public void Question_Movies(Dictionary<string, List<string>> movie)
        {
            movie.Add("Which film became the world's first full-length animated film?",
                new List<string> { "Snow White and the Seven Dwarfs", "Mickey Mouse", "The Cockroach and the Corn", "Three Bogatyrs" });

            movie.Add("Which director directed the film 'The Shawshank Redemption'?",
                new List<string> { "Frank Darabont", "Christopher Nolan", "Steven Spielberg", "Tim Burton" });

            movie.Add("What is depicted on the poster of the film 'The Green Mile'?",
                new List<string> { "Prison", "Cornfield", "Forest", "Ocean" });

            movie.Add("Which actor played the main role in the film 'Forrest Gump'?",
                new List<string> { "Tom Hanks", "Brad Pitt", "Leonardo DiCaprio", "Johnny Depp" });

            movie.Add("The film 'Star Wars: Episode IV - A New Hope' is the first part of the Star Wars saga. When was it first shown in cinemas?",
                new List<string> { "1977", "1981", "1985", "1973" });

            movie.Add("What is the name of the main antagonist in the film 'The Dark Knight Rises'?",
                new List<string> { "Benjamin Lockwood", "Joshua Pin", "Cobb", "Bane" });

            movie.Add("What is the title of the film about a chess game in which the main role was played by Max von Sydow?",
                new List<string> { "The Cheat", "Match", "Checkmate", "The Game of Life" });

            movie.Add("Who played the role of James Bond in the film 'The Spy Who Loved Me'?",
                new List<string> { "Roger Moore", "Sean Connery", "Timothy Dalton", "Pierce Brosnan" });

            movie.Add("In the film 'The Notebook', the main roles were played by Rachel McAdams and...",
                new List<string> { "Channing Tatum", "Zac Efron", "Liam Hemsworth", "Keith Harrin" });

            movie.Add("The film 'Bruce Almighty' with Jim Carrey is based on the book by...",
                new List<string> { "James Cameron", "Stephen King", "Chuck Palahniuk", "Nicholas Sparks" });
            //
            movie.Add("Which of the following movies were directed by Christopher Nolan?",
                new List<string> { "Interstellar", " The Shawshank Redemption", "Inception", "The Dark Knight" });

            movie.Add("In which films did Robert Downey Jr. star?",
                new List<string> { "Life of Pi", " Iron Man", "Sherlock Holmes", "Murder on the Orient Express" });

            movie.Add("Which of the following film studios were founded in Hollywood, USA?",
                new List<string> { "Paramount Pictures", "Bollywood Film Studios", "Universal Pictures", "Warner Bros. Pictures" });

            movie.Add("In which films did Meryl Streep appear?",
                new List<string> { "The Devil Wears Prada", "The Great Gatsby", "The Iron Lady", "Schindler's List" });

            movie.Add("Which of the following films won the Oscar for \"Best Picture\"?",
                new List<string> { "Birds", "The Great Exit", "Silence of the Lambs", "Shrek" });

            movie.Add("Which of the following actors won the Oscar for \"Best Actor\"?",
                new List<string> { "Leonardo DiCaprio", " Johnny Depp", "Denzel Washington", "Bradley Cooper" });

            movie.Add("Which of the following films were based on a book?",
                new List<string> { "Harry Potter and the Philosopher's Stone", "The Matrix", "The Bead Game", "Saving Private Ryan" });

            movie.Add("Which of the following films belong to the science fiction genre?",
                new List<string> { "Star Wars", "Inception", "Marley and Me", "The Chronicles of Narnia" });

            movie.Add("In which films did Tom Hanks star?",
                new List<string> { "Forrest Gump", "First Love", "Schindler's List", "Saving Private Ryan" });

            movie.Add("Which of the following films are animated?",
                new List<string> { "Monsters, Inc.", "The End of the World", " Ice Age", "Escape from Planet Earth" });
        }

        public void AddCorrectAnswers_Movies(Dictionary<string, List<int>> correctAnswersMovie)
        {
            correctAnswersMovie.Add("Which film became the world's first full-length animated film?", new List<int> { 0 });
            correctAnswersMovie.Add("Which director directed the film 'The Shawshank Redemption'?", new List<int> { 0 });
            correctAnswersMovie.Add("What is depicted on the poster of the film 'The Green Mile'?", new List<int> { 0 });
            correctAnswersMovie.Add("Which actor played the main role in the film 'Forrest Gump'?", new List<int> { 0 });
            correctAnswersMovie.Add("The film 'Star Wars: Episode IV - A New Hope' is the first part of the Star Wars saga. When was it first shown in cinemas?", new List<int> { 0 });
            correctAnswersMovie.Add("What is the name of the main antagonist in the film 'The Dark Knight Rises'?", new List<int> { 3 });
            correctAnswersMovie.Add("What is the title of the film about a chess game in which the main role was played by Max von Sydow?", new List<int> { 2 });
            correctAnswersMovie.Add("Who played the role of James Bond in the film 'The Spy Who Loved Me'?", new List<int> { 0 });
            correctAnswersMovie.Add("In the film 'The Notebook', the main roles were played by Rachel McAdams and...", new List<int> { 3 });
            correctAnswersMovie.Add("The film 'Bruce Almighty' with Jim Carrey is based on the book by...", new List<int> { 2 });
            //   
            correctAnswersMovies.Add("Which of the following movies were directed by Christopher Nolan?", new List<int> { 0,2,3 });
            correctAnswersMovies.Add("In which films did Robert Downey Jr. star?",new List<int> { 0,2,3 });
            correctAnswersMovies.Add("Which of the following film studios were founded in Hollywood, USA?", new List<int> { 0,1,3 });
            correctAnswersMovies.Add("In which films did Meryl Streep appear?", new List<int> { 0, 2 });
            correctAnswersMovies.Add("Which of the following films won the Oscar for \"Best Picture\"?",new List<int> { 1,2 });
            correctAnswersMovies.Add("Which of the following actors won the Oscar for \"Best Actor\"?", new List<int> { 0, 2 });
            correctAnswersMovies.Add("Which of the following films were based on a book?",new List<int> { 0, 2 });
            correctAnswersMovies.Add("Which of the following films belong to the science fiction genre?", new List<int> { 0, 1 });
            correctAnswersMovies.Add("In which films did Tom Hanks star?", new List<int> { 0,3 });
            correctAnswersMovies.Add("Which of the following films are animated?", new List<int> { 0, 2, 3 });
        }

        public void Question_Science(Dictionary<string, List<string>> science)
        {
            science.Add("What is the proportion of nitrogen in the air?", new List<string> { "78%", "21%", "1%", "0.04%" });
            
            science.Add("What is the lightest element in the periodic table?", new List<string> { "hydrogen", "helium", "lithium", "beryllium" });
            
            science.Add("Which element is responsible for the red color in pyrotechnics?", new List<string> { "strontium", "barium", "calcium", "copper" });
            
            science.Add("What is the chemical formula for water?", new List<string> { "H2O", "CO2", "O2", "C6H12O6" });
            
            science.Add("Which gas is used to fill lamps?", new List<string> { "neon", "argon", "helium", "krypton" });
            
            science.Add("What does an ammeter measure?", new List<string> { "electric current", "pressure", "temperature", "gravitational force" });
            
            science.Add("What is the freezing temperature of water on the Celsius scale?", new List<string> { "0°C", "-10°C", "100°C", "-0.01°C" });
            
            science.Add("What is a photon?", new List<string> { "quantum of light", "electric charge", "diamond", "elementary particle" });
            
            science.Add("Which element is most abundant in the Earth's crust?", new List<string> { "oxygen", "silicon", "aluminum", "magnesium" });
            
            science.Add("Which of the following statements about DNA is correct?", new List<string> { "contains genetic information", "located in cell nuclei", "has a double helical structure", "responsible for transmitting traits from parents to offspring" });
            //
            science.Add("Which of the following elements are noble gases?", new List<string> { "Helium", "Oxygen", "Neon", "Iron" });
            
            science.Add("Who among the following scientists is known for the theory of relativity?",
            new List<string> { "Isaac Newton", "Albert Einstein", "Charles Darwin", "Marie Curie" });

            science.Add("Which of the following are considered fundamental forces in nature?",
            new List<string> { "Electromagnetism", "Gravitational", "Thermal force", "Nuclear force" });

            science.Add("In which fields did Richard Feynman make significant contributions?",
            new List<string> { "Quantum Mechanics", "Geology", "Evolutionary Biology", "Quantum Electrodynamics" });

            science.Add("Which of the following planets are considered gas giants?",new List<string> { "Jupiter", "Mars", "Saturn", "Mercury" });

            science.Add("Who among the following scientists won a Nobel prize for their contributions to the discovery of DNA's structure?",
            new List<string> { "James Watson", "Albert Einstein", "Rosalind Franklin", "Francis Crick" });

            science.Add("Which of the following compounds are essential for human respiration?",
            new List<string> { "Carbon Dioxide", "Water", "Methane", "Oxygen" });

            science.Add("Which of the following phenomena are associated with the study of light?", new List<string> { "Reflection", "Combustion", "Refraction", "Fermentation" });

            science.Add("Who among the following is known for the periodic table of elements?", new List<string> { "Dmitri Mendeleev", "Galileo Galilei", "Antoine Lavoisier", "Max Planck" });
            science.Add("Which of the following animals are mammals?",new List<string> { "Whale", "Salmon","Bat", "Eagle" });
        }

        public void AddCorrectAnswers_Science(Dictionary<string, List<int>> correctAnswersScience)
        {
            correctAnswersScience.Add("What is the proportion of nitrogen in the air?", new List<int> { 0 });
            correctAnswersScience.Add("What is the lightest element in the periodic table?", new List<int> { 0 });
            correctAnswersScience.Add("Which element is responsible for the red color in pyrotechnics?", new List<int> { 0 });
            correctAnswersScience.Add("What is the chemical formula for water?", new List<int> { 0 });
            correctAnswersScience.Add("Which gas is used to fill lamps?", new List<int> { 0 });
            correctAnswersScience.Add("What does an ammeter measure?", new List<int> { 0 });
            correctAnswersScience.Add("What is the freezing temperature of water on the Celsius scale?", new List<int> { 2 });
            correctAnswersScience.Add("What is a photon?", new List<int> { 2 });
            correctAnswersScience.Add("Which element is most abundant in the Earth's crust?", new List<int> { 0 });
            correctAnswersScience.Add("Which of the following statements about DNA is correct?", new List<int> { 0 });
            //
            correctAnswersScience.Add("Which of the following elements are noble gases?", new List<int> { 0,2 });
            correctAnswersScience.Add("Who among the following scientists is known for the theory of relativity?",new List<int> { 1,2 });
            correctAnswersScience.Add("Which of the following are considered fundamental forces in nature?", new List<int> { 0,1,2});
            correctAnswersScience.Add("Which of the following planets are considered gas giants?", new List<int> { 0, 2 });
            correctAnswersScience.Add("Who among the following scientists won a Nobel prize for their contributions to the discovery of DNA's structure?",new List<int> { 0,3 });
            correctAnswersScience.Add("Which of the following compounds are essential for human respiration?",new List<int> { 0,1,3 });
            correctAnswersScience.Add("Which of the following phenomena are associated with the study of light?", new List<int> { 0, 2 });
            correctAnswersScience.Add("Who among the following is known for the periodic table of elements?", new List<int> { 0, 3 });
            correctAnswersScience.Add("Which of the following animals are mammals?", new List<int> { 0, 2 });
        }

        public void Question_Literature(Dictionary<string, List<string>> literature)
        {
            literature.Add("Who is the author of the novel 'Master and Margarita'",
                new List<string> { "Mikhail Bulgakov", "Fyodor Dostoevsky", "Leo Tolstoy", "Antoine de Saint-Exupéry" });

            literature.Add("Who is the author of the drama 'Romeo and Juliet'",
                new List<string> { "William Shakespeare", "Oscar Wilde", "Franz Kafka", "Gabriel Garcia Marquez" });

            literature.Add("What is the name of the main character in George Orwell's '1984'?",
                new List<string> { "Winston Smith", "Jack London", "Tom Sawyer", "Robert Capa" });

            literature.Add("Who is the diary of Anne Frank written by?",
                new List<string> { "A teenager hiding from the Nazis", "A girl writing about her life in the ghetto", "A playwright writing about war", "A famous romantic dreaming of a better world" });

            literature.Add("In which work of French writer Jules Verne does the main character travel into the depths of the Earth?",
                new List<string> { "Journey to the Center of the Earth", "Two Years Vacation", "The Fifteen-Year-Old Captain", "The Mysterious Island" });

            literature.Add("Which book by English writer J.K. Rowling was the first in the Harry Potter series?",
                new List<string> { "Harry Potter and the Philosopher's Stone", "Harry Potter and the Chamber of Secrets", "Harry Potter and the Prisoner of Azkaban", "Harry Potter and the Goblet of Fire" });

            literature.Add("Who is the author of the fairy tale 'Cinderella'?",
                new List<string> { "Charles Perrault", "Hans Christian Andersen", "Lewis Carroll", "Brothers Grimm" });

            literature.Add("In which novel does Jules Verne tell the adventures of Captain Nemo and his submarine 'Nautilus'?",
                new List<string> { "Twenty Thousand Leagues Under the Sea", "The Mysterious Island", "The End of the World", "The Mysterious Planet" });

            literature.Add("Who is the author of the tragedy 'Hamlet'?",
                new List<string> { "William Shakespeare", "Dante Alighieri", "Johann Wolfgang von Goethe", "Molière" });

            literature.Add("What is the name of the fairy tale about a girl who printed counterfeit money to save her father?",
                new List<string> { "The Frog Princess", "The Little Red Hen", "Thumbelina", "Ekaterina Ivanovna" });

            literature.Add("Which of the following works belong to the Renaissance period?", 
            new List<string> { "Don Quixote\" by Cervantes", "\"Sonnets\" by Shakespeare", "\"1984\" by Orwell", " \"The Master and Margarita\" by Bulgakov" });

            literature.Add("Which of the following are epic poems?", new List<string> { "\"Iliad\"", "\"Odyssey\"", "\"The Viy\" by Gogol", "\"The Song of Roland\"" });

            literature.Add("Which authors from the following are representatives of English literature?",
            new List<string> { "J.R.R. Tolkien", " J.K. Rowling", "Victor Hugo", "Fyodor Dostoevsky" });

            literature.Add("Which works are dramas?", new List<string> { "\"Macbeth\" by Shakespeare", "\"Hamlet\" by Shakespeare", "\"Anna Karenina\" by Tolstoy", "\"The Glass Bead Game\" by Hesse" });

            literature.Add("Which American authors are known for their novels about the American Dream?", new List<string> { "Mark Twain", "F. Scott Fitzgerald", "Ernest Hemingway", " John Updike" });

            literature.Add("Which works belong to the dystopian genre?", new List<string> { "\"Fahrenheit 451\" by Bradbury", "\"1984\" by Orwell", "\"Don Quixote\" by Cervantes", "\"Romeo and Juliet\" by Shakespeare" });

            literature.Add("Which of the following authors received the Nobel Prize in Literature?", new List<string> { "Bob Dylan", "Leo Tolstoy", "Gabriel García Márquez", "Fyodor Dostoevsky" });

            literature.Add("Which works are psychological novels?",
            new List<string> { "\"Crime and Punishment\" by Dostoevsky", "\"The Adventures of Huckleberry Finn\" by Twain", "\"The Call of the Wild\" by London", "\"The Hand and the Eye\" by Maupassant" });

            literature.Add("Which works tell about wars?", new List<string> { "\"War and Peace\" by Tolstoy", "\"All Quiet on the Western Front\" by Remarque", "\"The Glass Bead Game\" by Hesse", "\"The Adventures of Sherlock Holmes\" by Doyle" });

            literature.Add("Which works are known for their profound symbolism?",
            new List<string> { "\"The Master and Margarita\" by Bulgakov", "\"The Alchemist\" by Paulo Coelho", "\"Jane Eyre\" by Brontë", "\"Romeo and Juliet\" by Shakespeare" });
        }

        public void AddCorrectAnswers_Literature(Dictionary<string, List<int>> correctAnswersLiterature)
        {
            correctAnswersLiterature.Add("Who is the author of the novel 'Master and Margarita'?", new List<int> { 0 });
            correctAnswersLiterature.Add("Who is the author of the drama 'Romeo and Juliet'?", new List<int> { 0 });
            correctAnswersLiterature.Add("What is the name of the main character in George Orwell's '1984'?", new List<int> { 0 });
            correctAnswersLiterature.Add("Who is the diary of Anne Frank written by?", new List<int> { 0 });
            correctAnswersLiterature.Add("In which work of French writer Jules Verne does the main character travel into the depths of the Earth?", new List<int> { 0 });
            correctAnswersLiterature.Add("Which book by English writer J.K. Rowling was the first in the Harry Potter series?", new List<int> { 0 });
            correctAnswersLiterature.Add("Who is the author of the fairy tale 'Cinderella'?", new List<int> { 0 });
            correctAnswersLiterature.Add("In which novel does Jules Verne tell the adventures of Captain Nemo and his submarine 'Nautilus'?", new List<int> { 0 });
            correctAnswersLiterature.Add("Who is the author of the tragedy 'Hamlet'?", new List<int> { 0 });
            correctAnswersLiterature.Add("What is the name of the fairy tale about a girl who printed counterfeit money to save her father?", new List<int> { 3 });
            //
            correctAnswersLiterature.Add("Which of the following works belong to the Renaissance period?", new List<int> { 0, 1 });
            correctAnswersLiterature.Add("Which of the following are epic poems?", new List<int> { 0, 1, 3 });
            correctAnswersLiterature.Add("Which authors from the following are representatives of English literature?", new List<int> { 0, 1 });
            correctAnswersLiterature.Add("Which works are dramas?", new List<int> { 0, 1 });
            correctAnswersLiterature.Add("Which American authors are known for their novels about the American Dream?", new List<int> { 0, 1, 2 });
            correctAnswersLiterature.Add("Which works belong to the dystopian genre?", new List<int> { 0, 1 });
            correctAnswersLiterature.Add("Which of the following authors received the Nobel Prize in Literature?", new List<int> { 0, 2 });
            correctAnswersLiterature.Add("Which works are psychological novels?", new List<int> { 0, 3 });
            correctAnswersLiterature.Add("Which works tell about wars?", new List<int> { 0, 1 });
            correctAnswersLiterature.Add("Which works are known for their profound symbolism?", new List<int> { 0,1 });
        }

        public void Question_Mix(Dictionary<string, List<string>> mix_topic)
        {
            Question_History(mix_topic);
            Question_Geography(mix_topic);
            Question_Science(mix_topic);
            Question_Movies(mix_topic);
            Question_Literature(mix_topic);
        }
    }
}
