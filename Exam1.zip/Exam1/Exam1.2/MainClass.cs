﻿using Exam1._2;
using System;
using static System.Formats.Asn1.AsnWriter;
using static System.Runtime.InteropServices.JavaScript.JSType;

//Создать приложение «Викторина».
//Основная задача проекта: предоставить пользователю возможность проверить свои 
//знания в разных областях.
//Интерфейс приложения должен предоставлять такие возможности:
//■ При старте приложения пользователь вводит логин и пароль для входа. Если пользователь не зарегистрирован, он должен пройти процесс регистрации.
//■ При регистрации нужно указать:
//• логин(нельзя зарегистрировать уже существующий логин);
//• пароль;
//• дату рождения.
//■ После входа в систему пользователь может:
//• стартовать новую викторину;
//• посмотреть результаты своих прошлых викторин;
//• посмотреть Топ-20 по конкретной викторине;
//• изменить настройки: можно менять пароль и дату рождения;
//• выход.
//■ Для старта новой викторины пользователь должен выбрать раздел знаний викторины. Например: «История», «География», «Биология» и т.д. Также нужно 
//предусмотреть смешанную викторину, когда вопросы будут выбираться из разных 
//викторин по случайному принципу.
//■ Конкретная викторина состоит из двадцати вопросов. У каждого вопроса может 
//быть один или несколько правильных вариантов ответа. Если вопрос предполагает 
//несколько правильных ответов, а пользователь указал не все, вопрос не засчитывается.
//■ По завершении викторины пользователь получает количество правильно отвеченных вопросов, а также свое место в таблице результатов игроков викторины.
//Необходимо также разработать утилиту для создания и редактирования викторин 
//и их вопросов. Это приложение должно предусматривать вход по логину и паролю.

class MainClass
{
    public static void Exit_inAccount(string filePath)
    {
        Console.Write("Enter your login: ");
        string login_exit = Console.ReadLine();

        Console.Write("Enter your password: ");
        string password_exit = Console.ReadLine();

        Work_withFile fileManager = new Work_withFile();
        fileManager.SetFilePath(filePath);
        Loggin_Account exit = new Loggin_Account(login_exit, password_exit, fileManager);

        if (!exit.CheckLogin2(ref login_exit, false))
        {
            Console.WriteLine("Login does not exist in the file, returning to the start menu!" + '\n');
            return; // Return to the main menu
        }

        if (!exit.IsPasswordMatch(ref login_exit, ref password_exit))
        {
            Console.WriteLine("Password does not match, returning to the start menu!" + '\n');
            return; // Return to the main menu
        }
        Console.WriteLine($"Welcome, {login_exit}!" + '\n');

        Loggin_Account account = new Loggin_Account(login_exit, password_exit, fileManager);

        FuncMenu_Quiz(ref login_exit, ref account, ref filePath);
    }

    public static void Registration_inProgram(string filePath)
    {
        // Create account

        Console.Write("Enter your login (minimum 3 characters): ");
        string login = Console.ReadLine();

        Console.Write("Enter your password (minimum 8 characters): ");
        string password = Console.ReadLine();

        Console.Write("Enter your date (must be correct): ");
        string date = Console.ReadLine();

        // Create Work_withFile object
        Work_withFile fileManager = new Work_withFile();
        fileManager.SetFilePath(filePath);

        // Create Loggin_Account object for checking
        Loggin_Account accountForCheck = new Loggin_Account(login, password, date, fileManager);

        // Check if the account login already exists
        if (!accountForCheck.CheckLogin2(ref login))
        {
            Console.WriteLine("Login already exists, returning to the start menu.");
            Main();
            return;
        }

        // Create Loggin_Account object for saving
        Loggin_Account account = new Loggin_Account(login, password, date, fileManager);
        // Save account information to the file
        fileManager.information.AppendLine(account.ToString());
        fileManager.CreateFile_txt();

        FuncMenu_Quiz(ref login, ref account, ref filePath);
    }

    public static void FuncMenu_Quiz(ref string user_loggin, ref Loggin_Account account, ref string filePath)
    {
        while (true)
        {
            Console.WriteLine("1. Start new quiz" + '\n' + "2. Look at past results" + '\n' + "3. Look at top-20 records" + '\n'
                            + "4. Change account information (date or password)" + '\n' + "0. Go to the main menu");

            Console.Write("Enter: ");
            string input_menu = Console.ReadLine();

            if (int.TryParse(input_menu, out int menu))
            {
                switch (menu)
                {
                    case 1:
                        Console.WriteLine("Enter topic:" + '\n' + "1. History\n2. Geography\n3. Science\n4. Movies\n5. Literature\n6. Mix (hard)");

                        string input_topic = Console.ReadLine();
                        if (int.TryParse(input_topic, out int topic))
                        {
                            switch (topic)
                            {
                                case 1:
                                    Quiz quiz_1 = new Quiz(topic, filePath, user_loggin);
                                    break;
                                case 2:
                                    Quiz quiz_2 = new Quiz(topic, filePath, user_loggin);
                                    break;
                                case 3:
                                    Quiz quiz_3 = new Quiz(topic, filePath, user_loggin);
                                    break;
                                case 4:
                                    Quiz quiz_4 = new Quiz(topic, filePath, user_loggin);
                                    break;
                                case 5:
                                    Quiz quiz_5 = new Quiz(topic, filePath, user_loggin);
                                    break;
                                case 6:
                                    Quiz quiz_6 = new Quiz(topic, filePath, user_loggin);
                                    break;
                                default:
                                    break;
                            }
                        }
                        else
                        {

                        }
                        break;
                    case 2:
                        // Create Work_withFile object
                        Work_withFile fileManager_history = new Work_withFile();
                        fileManager_history.SetFilePath(filePath);

                        string history = fileManager_history.ReadAccountHistory(user_loggin);
                        Console.WriteLine(history);
                        break;
                    case 3:
                        // Your code to get top-20 results
                        Work_withFile fileManager_top = new Work_withFile();
                        fileManager_top.SetFilePath(filePath);
                        var topScores = fileManager_top.GetTopScores();

                        Console.WriteLine("Top 20 scores:");
                        foreach (var score in topScores)
                        {
                            // Only output lines that contain "Score:"
                            if (score.Contains("Score:"))
                            {
                                Console.WriteLine(score);
                            }
                        }
                        break;
                    case 4:
                        Console.WriteLine("Change: 1. Date\t2. Password");

                        Console.Write("Enter: ");
                        string input_temp = Console.ReadLine();

                        if (int.TryParse(input_temp, out int change))
                        {
                            switch (change)
                            {
                                case 1:
                                    Console.Write('\n' + "Write the new date: ");
                                    string newDate = Console.ReadLine();
                                    account.UpdateAccountDate(user_loggin, newDate);
                                    break;
                                case 2:
                                    Console.Write('\n' + "Write the new password: ");
                                    string newPassword = Console.ReadLine();
                                    account.UpdateAccountPassword(user_loggin, newPassword);
                                    break;
                                default:
                                    break;
                            }
                        }
                        else
                        {
                            Console.WriteLine("Choice needs to be a number!");
                        }
                        break;
                    case 0:
                        return;  // Return to the main menu
                    default:
                        Console.WriteLine("Error with your choice! Go to the menu!");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Choice needs to be a number! Go to the menu!");
            }
        }
    }

    public static void Main()
    {
        // My filepath for the database
        string filePath = "C:\\Users\\coolm\\source\\repos\\Exam1\\Exam1.2\\Accounts.txt";

        while (true)
        {
            Console.Write("\n1. Log in to your account" + '\n' + "2. Create a new account" + '\n' + "0. Close" + '\n' + "Your choice: ");
            string input_exitMenu = Console.ReadLine();

            if (int.TryParse(input_exitMenu, out int exitMenu))
            {
                switch (exitMenu)
                {
                    case 1:
                        Exit_inAccount(filePath);
                        break;
                    case 2:
                        Registration_inProgram(filePath);
                        break;
                    case 0:
                        Environment.Exit(0); // This will terminate the program
                        break;
                    default:
                        Console.WriteLine("Invalid choice!");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Error!\tChoice needs to be a number!!!");
            }
        }
    }
}