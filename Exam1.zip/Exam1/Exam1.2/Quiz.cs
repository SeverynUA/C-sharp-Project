﻿using System;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text.RegularExpressions;
using static System.Formats.Asn1.AsnWriter;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Exam1._2
{
    public class Quiz : Question_Quiz
    {
        // Dictionaries to store questions for different topics
        public Dictionary<string, List<string>> history;
        public Dictionary<string, List<string>> geography;
        public Dictionary<string, List<string>> science;
        public Dictionary<string, List<string>> movies;
        public Dictionary<string, List<string>> literature;
        public Dictionary<string, List<string>> mix_topic;

        // Counters to keep track of correct answers and the question queue
        public int correct_answers, queue;

        // Dictionaries to store correct answers for different topics
        public Dictionary<string, List<int>> correctAnswersHistory;
        public Dictionary<string, List<int>> correctAnswersGeography;
        public Dictionary<string, List<int>> correctAnswersScience;
        public Dictionary<string, List<int>> correctAnswersMovies;
        public Dictionary<string, List<int>> correctAnswersLiterature;
        public Dictionary<string, List<int>> correctAnswersMixTopic;

        // Instance of Work_withFile to handle file operations
        public Work_withFile FileWorker { get; set; }

        public Quiz(int choice_game, string filepath, string login)
        {
            FileWorker = new Work_withFile();  // Create a new Work_withFile object to record the history
            FileWorker.SetFilePath(filepath);  // Specify the file path where the history will be saved

            // Initialize dictionaries for questions and correct answers
            history = new Dictionary<string, List<string>>();
            geography = new Dictionary<string, List<string>>();
            science = new Dictionary<string, List<string>>();
            movies = new Dictionary<string, List<string>>();
            literature = new Dictionary<string, List<string>>();
            mix_topic = new Dictionary<string, List<string>>();

            correctAnswersHistory = new Dictionary<string, List<int>>();
            correctAnswersGeography = new Dictionary<string, List<int>>();
            correctAnswersScience = new Dictionary<string, List<int>>();
            correctAnswersMovies = new Dictionary<string, List<int>>();
            correctAnswersLiterature = new Dictionary<string, List<int>>();
            correctAnswersMixTopic = new Dictionary<string, List<int>>();

            // Initialize counters
            queue = 0;
            correct_answers = 0;

            if (choice_game >= 1 && choice_game <= 6)
            {
                switch (choice_game)
                {
                    case 1:
                        Question_History(history);
                        AddCorrectAnswers_History(correctAnswersHistory); // Added a call to the method for adding correct answers
                        Ask(login, "History", history.ToList());
                        break;
                    case 2:
                        Question_Geography(geography);
                        AddCorrectAnswers_Geography(correctAnswersGeography);
                        Ask(login, "Geography", geography.ToList());
                        break;
                    case 3:
                        Question_Science(science);
                        AddCorrectAnswers_Science(correctAnswersScience);
                        Ask(login, "Science", science.ToList());
                        break;
                    case 4:
                        Question_Movies(movies);
                        AddCorrectAnswers_Movies(correctAnswersMovies);
                        Ask(login, "Movies", movies.ToList());
                        break;
                    case 5:
                        Question_Literature(literature);
                        AddCorrectAnswers_Literature(correctAnswersLiterature);
                        Ask(login, "Literature", literature.ToList());
                        break;
                    case 6:
                        Question_Mix(mix_topic);
                        AddCorrectAnswers_History(correctAnswersHistory);
                        AddCorrectAnswers_Geography(correctAnswersGeography);
                        AddCorrectAnswers_Science(correctAnswersScience);
                        AddCorrectAnswers_Movies(correctAnswersMovies);
                        AddCorrectAnswers_Literature(correctAnswersLiterature);
                        Ask(login, "Mixtopic", mix_topic.ToList());
                        break;
                    default:
                        break;
                }
            }
        }

        // Method to conduct the quiz for a specific topic
        public void Ask(string userName, string topic, List<KeyValuePair<string, List<string>>> questions)
        {
            var random = new Random();

            while (questions.Count > 0)
            {
                var randomQuestionIndex = random.Next(questions.Count);
                var randomQuestion = questions[randomQuestionIndex];

                Console.WriteLine("\nQuestion: " + randomQuestion.Key);

                for (int i = 0; i < randomQuestion.Value.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {randomQuestion.Value[i]}");
                }

                Console.Write("Please input your answers' number separated by comma: ");
                var userAnswer = Console.ReadLine();

                // Check if the user provided any answer
                if (string.IsNullOrWhiteSpace(userAnswer))
                {
                    Console.WriteLine("No answer provided. Skipping the question.");
                    questions.RemoveAt(randomQuestionIndex);
                    continue;
                }

                var userAnswerNumbers = userAnswer.Split(',').Select(str => str.Trim()).Where(IsNumericAnswer).Select(int.Parse).ToList();

                questions.RemoveAt(randomQuestionIndex);  // Remove the question from the list

                if (CheckAnswer(randomQuestion.Key, userAnswerNumbers))
                {
                    correct_answers++;
                    Console.WriteLine("Correct answer!");
                }
            }

            // Output the quiz results
            Console.WriteLine($"You've completed the Quiz on {topic}. Your score: {correct_answers} correct answers.");

            // Save the quiz history
            FileWorker.WriteAccountHistory(userName, $"Topic: {topic}, Score: {correct_answers}");
        }

        // Method to check if the user's answers are correct
        public bool CheckAnswer(string question, List<int> userAnswerNumbers)
        {
            List<int> correctAnswerIndices;

            // Retrieve correct answer indices from the corresponding dictionary based on the question's topic
            if (correctAnswersHistory.TryGetValue(question, out correctAnswerIndices) ||
                correctAnswersGeography.TryGetValue(question, out correctAnswerIndices) ||
                correctAnswersScience.TryGetValue(question, out correctAnswerIndices) ||
                correctAnswersMovies.TryGetValue(question, out correctAnswerIndices) ||
                correctAnswersLiterature.TryGetValue(question, out correctAnswerIndices) ||
                correctAnswersMixTopic.TryGetValue(question, out correctAnswerIndices))
            {
                // Convert indices to zero-based, because user inputs are one-based.
                userAnswerNumbers = userAnswerNumbers.Select(n => n - 1).ToList();

                // Check if all user's answers are correct
                bool isCorrect = correctAnswerIndices.All(answer => userAnswerNumbers.Contains(answer));

                if (!isCorrect)
                {
                    Console.WriteLine("Incorrect answer. The correct answer(s) are:");
                    foreach (int correctIndex in correctAnswerIndices)
                    {
                        Console.WriteLine($"{correctIndex + 1}. {history[question][correctIndex]}");
                    }
                }

                return isCorrect;
            }
            else
            {
                Console.WriteLine($"The question '{question}' does not exist in the correct answers dictionary.");
                return false;
            }
        }

        // Method to check if an input is a numeric answer
        private bool IsNumericAnswer(string input)
        {
            return int.TryParse(input, out _);
        }
    }
}