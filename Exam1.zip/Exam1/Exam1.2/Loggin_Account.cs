﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam1._2
{
    internal class Loggin_Account : Work_withFile
    {
        protected string login { get; set; }
        protected string password { get; set; }
        protected string date { get; set; }
        private Work_withFile fileManager;

        public Loggin_Account(string? login, string? password, string? date, Work_withFile fileManager)
        {
            this.fileManager = fileManager;

            // First, check the login format and if it already exists in the file
            if (!CheckLogin1(ref login))
            {
                Console.WriteLine("Returning to the start menu!" + '\n');
                MainClass.Main();
            }

            // Check the password format
            if (!CheckPassword(ref password))
            {
                Console.WriteLine("Returning to the start menu!" + '\n');
                MainClass.Main();
            }

            // Check if the provided date is in the correct format
            if (DateTime.TryParse(date, out DateTime check_date))
            {
                this.date = date;
            }
            else
            {
                Console.WriteLine("Date was not correct!" + '\n');
                Console.WriteLine("Returning to the start menu!" + '\n');
                MainClass.Main();
            }

            this.login = login;
            this.password = password;

            SaveAccountInfo(); // Save the account information when creating the object.
        }

        public Loggin_Account(string login, string password, Work_withFile fileManager)
        {
            this.login = login;
            this.password = password;
            this.fileManager = fileManager;
        }

        // First check on login symbols
        private bool CheckLogin1(ref string? login)
        {
            int length = login.Length;

            if (length >= 3)
            {
                // Check if the login already exists in the file
                if (CheckLogin2(ref login))
                {
                    return true;
                }
                else
                {
                    Console.WriteLine("Login can't be repeated!" + '\n' + "Please write a new one!" + '\n');
                    return false;
                }
            }
            else
            {
                Console.WriteLine("Minimum symbols in login is 3!" + '\n');
                return false;
            }
        }

        // Second search in the file for the login
        public bool CheckLogin2(ref string? login)
        {
            if (fileManager == null)
            {
                Console.WriteLine("fileManager is null. Please initialize it before calling this method.");
                return false;
            }

            if (string.IsNullOrEmpty(fileManager.filePath) || string.IsNullOrEmpty(login))
            {
                return false;
            }

            try
            {
                using (StreamReader sr = new StreamReader(fileManager.filePath))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        if (line.Contains($"Login: {login}"))
                        {
                            Console.WriteLine($"Login '{login}' already exists in the file.");
                            return false;
                        }
                    }
                }
            }
            catch (IOException)
            {
                Console.WriteLine("Error reading the file.");
                return false;
            }

            return true;
        }

        public bool CheckLogin2(ref string? login, bool isRegistering)
        {
            if (string.IsNullOrEmpty(fileManager.filePath) || string.IsNullOrEmpty(login))
            {
                return false;
            }

            try
            {
                using (StreamReader sr = new StreamReader(fileManager.filePath))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        if (line.Contains($"Login: {login}"))
                        {
                            if (isRegistering)
                            {
                                Console.WriteLine($"Login '{login}' already exists in the file.");
                                return false;
                            }
                            else
                            {
                                // Successful login if the login is found
                                return true;
                            }
                        }
                    }
                }
            }
            catch (IOException)
            {
                Console.WriteLine("Error reading the file.");
                return false;
            }

            // If the login is not found in the file:
            // - for registration, this is a success
            // - for login, this is an error
            return isRegistering;
        }

        private bool CheckPassword(ref string? password)
        {
            if (string.IsNullOrEmpty(password))
            {
                Console.WriteLine("Password cannot be empty!" + '\n');
                return false;
            }

            if (password.Length < 8)
            {
                Console.WriteLine("Minimum symbols in password is 8!" + '\n');
                return false;
            }

            return true;
        }

        public bool IsPasswordMatch(ref string login, ref string password)
        {
            // Make sure the file path exists.
            if (string.IsNullOrEmpty(fileManager.filePath))
            {
                Console.WriteLine("filePath is null or empty. Please specify a valid file path.");
                return false;
            }

            try
            {
                // Open the file for reading.
                using (StreamReader sr = new StreamReader(fileManager.filePath))
                {
                    string line;
                    string passwordLine = null;
                    // Read the file line by line.
                    while ((line = sr.ReadLine()) != null)
                    {
                        // If the line contains the required login, save the next line (password).
                        if (line.Contains($"Login: {login}"))
                        {
                            passwordLine = sr.ReadLine();
                            // Check if the password from the file matches the entered password.
                            if (passwordLine == $"Password: {password}")
                            {
                                return true;
                            }
                        }
                    }
                }
            }
            catch (IOException)
            {
                Console.WriteLine("Error reading the file.");
                return false;
            }

            Console.WriteLine("Your password is incorrect!");
            return false;
        }

        public bool UpdateAccountDate(string login, string newDate)
        {
            // List to hold all lines in the file.
            List<string> lines = new List<string>();
            bool loginFound = false;

            try
            {
                using (StreamReader sr = new StreamReader(fileManager.filePath))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        if (line.Contains($"Login: {login}"))
                        {
                            loginFound = true;
                        }

                        // If the line contains the date for the found login, update the date.
                        if (loginFound && line.Contains("Date: "))
                        {
                            line = "Date: " + newDate;
                            loginFound = false;  // Reset the flag.
                        }

                        lines.Add(line);
                    }
                }

                // Write the updated lines back to the file.
                using (StreamWriter sw = new StreamWriter(fileManager.filePath))
                {
                    foreach (string line in lines)
                    {
                        sw.WriteLine(line);
                    }
                }
            }
            catch (IOException)
            {
                Console.WriteLine("Error reading or writing the file.");
                return false;
            }
            Console.WriteLine('\n');
            return true;
        }

        public bool UpdateAccountPassword(string login, string newPassword)
        {
            // List to hold all lines in the file.
            List<string> lines = new List<string>();
            bool loginFound = false;

            try
            {
                using (StreamReader sr = new StreamReader(fileManager.filePath))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        if (line.Contains($"Login: {login}"))
                        {
                            loginFound = true;
                        }

                        // If the line contains the password for the found login, update the password.
                        if (loginFound && line.Contains("Password: "))
                        {
                            line = "Password: " + newPassword;
                            loginFound = false;  // Reset the flag.
                        }

                        lines.Add(line);
                    }
                }

                // Write the updated lines back to the file.
                using (StreamWriter sw = new StreamWriter(fileManager.filePath))
                {
                    foreach (string line in lines)
                    {
                        sw.WriteLine(line);
                    }
                }
            }
            catch (IOException)
            {
                Console.WriteLine("Error reading or writing the file.");
                return false;
            }
            Console.WriteLine('\n');
            return true;
        }

        public void SaveAccountInfo()
        {
            information.AppendLine($"Login: {login}");
            information.AppendLine($"Password: {password}");
            information.AppendLine($"Date: {date}");

            // Added: display information after saving
            Console.WriteLine($"\nSaved account info: \n{information.ToString()}");
        }

        public override string ToString()
        {
            return $"Login: {login}\nPassword: {password}\nDate: {date}";
        }
    }
}