﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam1._2
{
    public class Work_withFile
    {
        public StringBuilder information;
        public string? filePath { get; set; }

        public Work_withFile()
        {
            information = new StringBuilder();
        }

        public void SetFilePath(string filePath)
        {
            this.filePath = filePath;
        }

        public void CreateFile_txt()
        {
            if (information.Length == 0)
            {
                Console.WriteLine("Information was empty!" + '\n');
                return;
            }

            using (StreamWriter sw = new StreamWriter(filePath, true))
            {
                sw.Write(information.ToString());
            }
        }

        public void ReadFile_txt(string filePath)
        {
            information = new StringBuilder();

            using (StreamReader sr = new StreamReader(filePath))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    information.AppendLine(line);
                }
            }
        }

        public void WriteAccountHistory(string login, string gameHistory)
        {
            if (string.IsNullOrWhiteSpace(filePath)) throw new InvalidOperationException("File path is not set.");

            // Prepare information to be written
            string informationToWrite = $"{login}: {gameHistory}\n";
            // Append information to the file
            using (StreamWriter sw = new StreamWriter(filePath, true))
            {
                sw.Write(informationToWrite);
            }
        }

        public string ReadAccountHistory(string login)
        {
            if (string.IsNullOrWhiteSpace(filePath)) throw new InvalidOperationException("File path is not set.");

            using (StreamReader sr = new StreamReader(filePath))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    if (line.StartsWith(login + ":"))
                    {
                        return $"User {login} has the following quiz history:\n{line.Substring(login.Length + 1)}";
                    }
                }
            }

            return "No history found for the specified login.";
        }

        // Method to get the top 20 scores
        public List<string> GetTopScores()
        {
            // Make sure filePath is specified
            if (string.IsNullOrEmpty(filePath))
            {
                Console.WriteLine("FilePath is not set!" + '\n');
                return new List<string>();
            }

            // Read all lines from the file
            var lines = File.ReadLines(filePath);

            // Sort lines in descending order of scores
            var sortedLines = lines.OrderByDescending(line =>
            {
                // Only lines starting with the user's name and containing "Score:"
                if (line.Contains("Score:"))
                {
                    var parts = line.Split(new string[] { ": " }, StringSplitOptions.None);
                    if (parts.Length < 3) // There should be at least 3 parts: "Username: Topic: Score"
                        return 0;
                    if (!int.TryParse(parts[2], out int score))
                        return 0;
                    return score;
                }
                else
                    return 0;
            });

            // Return the top 20 scores
            return sortedLines.Take(20).ToList();
        }

        // Method to write user's score to the file
        public void WriteUserScore(string username, int score)
        {
            // Make sure filePath is specified
            if (string.IsNullOrEmpty(filePath))
            {
                Console.WriteLine("FilePath is not set!" + '\n');
                return;
            }

            // Add the user's score to the file
            using (StreamWriter sw = new StreamWriter(filePath, true))
            {
                sw.WriteLine($"{username}: {score}");
            }
        }

        public override string ToString()
        {
            return $"Original in class: {information}\n";
        }
    }
}
